import React from "react";
import style from "./Perfil.module.css";

const Perfil = () => {
  return (
    <div className={style["container"]}>
      <div className={style["banner"]}>
        <div className={style["Fundo-foto"]}>
          <div>
            <img className={style["foto"]} src="/img/logo-solPoente.jpg" alt="logo" />
          </div>
        </div>
        <div className={style["icones"]}>
          <img className={style["icone"]} src="img/whatsapp.png" alt="whatsapp" />
          <img className={style["icone"]} src="img/instagram.png" alt="instagram" />
          <img className={style["icone"]} src="img/facebook.png" alt="facebook" />
          <img className={style["icone"]} src="img/email.png" alt="email" />
          <img className={style["icone"]} src="img/telefone.png" alt="telefone" />
        </div>
        <img className={style["icone-editar"]} src="img/editar.png" alt="editar-perfil" />
      </div>
      <div className={style["container-disponivel"]}>
        <div className={style["two-container"]}>
          <div className={style["titulo-container"]}>
            <h3 className={style["titulo"]}>Principais produtos</h3>
            <div className={style["produto-container"]}>
              <img className={style["produto"]} src="img/milho.jpg" alt="milho" />
              <img className={style["produto"]} src="img/soja.jpg" alt="soja" />
              <img className={style["produto"]} src="img/laranja.png" alt="laranja" />
            </div>
          </div>
          <div className={style["titulo-container"]}>
            <h3 className={style["titulo"]}>Produtos disponíveis</h3>
            <div className={style["produto-container"]}>
              <img className={style["produto"]} src="img/milho.jpg" alt="milho disponível" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Perfil;