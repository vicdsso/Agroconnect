// Importando React e useState Hook
import React from "react";
import style from "./NavBar.module.css"

// Componente da Barra de Navegação
const NavBar = () => {
  
  return (
    <div className={style["home-container"]}>
      <div className={style["banner-container"]}>
       
        
        <div className={style["top-bar"]}>
          <img src="/img/logo.png" alt="Logo" className={style["logo"]} />
          <h4 className={style.agroconnect}>Agrocconect</h4>
          <ul className={style["menu"]}>
            <li><a href="#">Home</a></li>
            <li><a href="#">Sobre</a></li>
            <li className={style["dropdown"]}>
              <a href="#" className={style["dropbtn"]}>Publicações</a>
              <div className={style["dropdown-content"]}>
                <a href="#">Maquinas</a>
                <a href="#">Serviços</a>
                <a href="#">Produtos</a>
              </div>
            </li>
            <li>
            <input type="checkbox" id="search-toggle" class={style["search-toggle"]} />
<div className={style["search-bar"]}>
  <label htmlFor="search-toggle" className={style["search-icon"]}></label>
  <input type="text" placeholder="Pesquisar..." className={style["search-input"]} />
</div>
            </li>
            <li><a href="#">Log in</a></li>
          </ul>
        </div>
      </div>
    
 
    </div>
  );
};




export default NavBar;
