import React from "react";
import "./App.css";
import Produtos from "./components/Publicacoes/Produtos";
import Maquinas from "./components/Publicacoes/Maquinas";
import Servicos from "./components/Publicacoes/Servicos";
import Home from  "./components/Publicacoes/Homepage/Home";

function App() {
  return (
    <>
      <Maquinas></Maquinas>
      <Servicos></Servicos>
      <Produtos></Produtos>
      <Home></Home>
    </>
  );
}

export default App;
