﻿namespace Services
{
    internal class Sessao
    {
    }
}